// Default Imports
import "babylonjs";
import "babylonjs-gui";
import "babylonjs-loaders";
import "babylonjs-materials";
import "babylonjs-inspector";
import "babylonjs-toolkit";

// Project Script Bundle
import scriptBundleUrl from "./classes/default.playground.js?url";  // Note: This will be placed in the root folder in the build output

class GameManager {
    public static get IsDevelopmentMode(): boolean { return import.meta.env.DEV; }
    public static async InitializeRuntime(scene:BABYLON.Scene, navigateToFunction:any = null, enablePhysics:boolean = true, showLoadingScreen:boolean = true, hideEngineLoadingUI:boolean = false): Promise<void> {
        if (scene.isDisposed) return; // Note: Strict mode safety
        await TOOLKIT.SceneManager.InitializeRuntime(scene.getEngine(), { showDefaultLoadingScreen: showLoadingScreen, hideLoadingUIWithEngine: hideEngineLoadingUI });
        if (scene.isDisposed) return; // Note: Strict mode safety

        // Set React Navigation Hook (Note: Remark or remove to disable navigation from scene)
        TOOLKIT.SceneManager.SetReactNavigationHook(scene, navigateToFunction);

        // Havok is only loaded once globally AFTER TOOLKIT.SceneManager.InitializeRuntime
        if (enablePhysics)
        {
            globalThis.HAVOKPLUGIN_JS = globalThis.HAVOKPLUGIN_JS || await BABYLON.Tools.LoadScriptAsync("/scripts/havok.js");
            if (globalThis.HK == null || globalThis.HKP == null)
            {
                // @ts-ignore - This initializes fresh physics for this scene
                globalThis.HK = await HavokPhysics();
                globalThis.HKP = new BABYLON.HavokPlugin(false);
            }
            if (!scene.isDisposed && globalThis.HK != null && globalThis.HKP != null)
            {
                scene.enablePhysics(new BABYLON.Vector3(0,-9.81,0), globalThis.HKP);
            }
            const cleanupGlobals = () =>
            {
                if (globalThis["HKP"]) delete globalThis["HKP"];
                if (globalThis["HK"]) delete globalThis["HK"];
            };
            if (!scene.isDisposed)
            {
                scene.onDisposeObservable.addOnce(cleanupGlobals);
            }
            else
            {
                cleanupGlobals(); // Note: Force clean up if scene was disposed already
            }
        }

        // Bundle is only loaded once globally AFTER TOOLKIT.SceneManager.InitializeRuntime
        globalThis.SCRIPTBUNDLE_JS = globalThis.SCRIPTBUNDLE_JS || await BABYLON.Tools.LoadScriptAsync(scriptBundleUrl);
    }
}

export default GameManager;